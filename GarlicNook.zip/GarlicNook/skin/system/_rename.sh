#!/bin/bash

# Check if the script was provided with at least one argument
if [ $# -lt 1 ]; then
    echo "Usage: $0 <argument>"
    exit 1
fi

# The first argument is stored in $1
input_argument="$1"

# Check the value of the input argument and take different actions
if [ "$input_argument" == "change" ]; then
    mv ATARI.png ATARI2600.PNG
    mv FC.png NES.PNG
    mv GB.png GAMEBOY.PNG
    mv GBA.png GAMEBOYADVANCE.PNG
    mv GBC.png GAMEBOYCOLOR.PNG
    mv GG.png GAMEGEAR.PNG
    mv LYNX.png ATARILYNX.PNG
    mv MD.png GENESIS.PNG
    mv MS.png MASTERSYSTEM.PNG
    mv PCE.png TURBOGRAFX-16.PNG
    mv PCECD.png PCENGINE-CD.PNG
    mv PS.png PLAYSTATION.PNG
    mv SFC.png SNES.PNG
elif [ "$input_argument" == "putback" ]; then
    mv ATARI2600.PNG ATARI.PNG
    mv NES.PNG FC.PNG
    mv GAMEBOY.PNG GB.PNG
    mv GAMEBOYADVANCE.PNG GBA.PNG
    mv GAMEBOYCOLOR.PNG GBC.PNG
    mv GAMEGEAR.PNG GG.PNG
    mv ATARILYNX.PNG LYNX.PNG
    mv GENESIS.PNG MD.PNG
    mv MASTERSYSTEM.PNG MS.PNG
    mv TURBOGRAFX-16.PNG PCE.PNG
    mv PCENGINE-CD.PNG PCECD.PNG
    mv PLAYSTATION.PNG PS.PNG
    mv SNES.PNG SFC.PNG
else
    echo "Invalid argument: $input_argument"
fi